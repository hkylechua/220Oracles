import assert from "assert";

import type { StableMatcher, StableMatcherWithTrace } from "../include/stableMatching.js";

export function generateInput(n: number): number[][] {
  // TODO
  const data: number[][] = [];
  for (let i = 0; i < n; i++) {
    const temp = [];
    for (let j = 0; j < n; j++) {
      temp.push(j);
    }
    data.push(temp);
  }
  return data.map(arr => performFisherYates(arr));
}

export function performFisherYates(arr: number[]): number[] {
  for (let i = arr.length - 1; i >= 1; i--) {
    const j = randomInt(0, i + 1);
    const temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }
  return arr;
}

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const NUM_TESTS = 20; // Change this to some reasonably large value
const N = 6; // Change this to some reasonable size

/**
 * Tests whether or not the supplied function is a solution to the stable matching problem.
 * @param makeStableMatching A possible solution to the stable matching problem
 * @throws An `AssertionError` if `makeStableMatching` in not a solution to the stable matching problem
 */
export function stableMatchingOracle(makeStableMatching: StableMatcher): void {
  for (let i = 0; i < NUM_TESTS; ++i) {
    const companies = generateInput(N);
    const candidates = generateInput(N);
    const hires = makeStableMatching(companies, candidates);

    assert(companies.length === hires.length, "Hires length is correct.");

    // TODO: More assertions go here.
    assert(companies.length === hires.length, "Hires length is correct.");
    assert(companies.length === candidates.length, "We have the same amount of companies and candidates");
    assert(candidates.length === hires.length, "All candidates are being hired");
    hires.forEach(obj => {
      const company = companies[obj.company];
      hires.forEach(loopObj => {
        if (hires.indexOf(obj) !== hires.indexOf(loopObj)) {
          const newCandidate = candidates[loopObj.candidate];
          assert(
            !(
              company.indexOf(loopObj.candidate) < company.indexOf(obj.candidate) &&
              newCandidate.indexOf(obj.company) < newCandidate.indexOf(loopObj.company)
            )
          );
        }
      });
    });
  }
}

// Part B

/**
 * Tests whether or not the supplied function follows the supplied algorithm.
 * @param makeStableMatchingTrace A possible solution to the stable matching problem and its possible steps
 * @throws An `AssertionError` if `makeStableMatchingTrace` does not follow the specified algorithm, or its steps (trace)
 * do not match with the result (out).
 */
export function stableMatchingRunOracle(makeStableMatchingTrace: StableMatcherWithTrace): void {
  for (let i = 0; i < NUM_TESTS; ++i) {
    const companies = generateInput(N);
    const candidates = generateInput(N);
    const { trace, out } = makeStableMatchingTrace(companies, candidates);

    // Create a copy of the preferences to keep track of the next proposal for each company and candidate
    const companyPreferences = companies.map(company => [...company]);
    const candidatePreferences = candidates.map(candidate => [...candidate]);

    // Initialize all companies and candidates as unmatched
    const unmatchedCompanies = new Set<number>(companies.map((_, idx) => idx));
    const unmatchedCandidates = new Set<number>(candidates.map((_, idx) => idx));

    // Check if the offer sequence in the trace is valid
    for (const offer of trace) {
      const { from, to, fromCo } = offer;

      // Check if the party making the offer is currently unmatched and hasn't exhausted their preference list
      assert(
        fromCo
          ? unmatchedCompanies.has(from) && companyPreferences[from].length > 0
          : unmatchedCandidates.has(from) && candidatePreferences[from].length > 0,
        "Invalid offer from a matched party or a party that has exhausted their preference list"
      );

      // Check if the offer is being made to the next preferred partner
      assert(
        fromCo ? companyPreferences[from][0] === to : candidatePreferences[from][0] === to,
        "Offer not being made to the next preferred partner"
      );

      // Remove the top choice from the preference list of the party making the offer
      if (fromCo) {
        companyPreferences[from].shift();
      } else {
        candidatePreferences[from].shift();
      }

      // If the receiving party is already matched, check if they prefer the new offer
      if (fromCo ? !unmatchedCandidates.has(to) : !unmatchedCompanies.has(to)) {
        const currentPartnerIdx = out.findIndex(hire => (fromCo ? hire.candidate === to : hire.company === to));
        assert(currentPartnerIdx !== -1, "Current partner not found in output");

        const currentPartner = fromCo ? out[currentPartnerIdx].company : out[currentPartnerIdx].candidate;
        assert(
          (fromCo ? candidates[to] : companies[to]).indexOf(from) <
            (fromCo ? candidates[to] : companies[to]).indexOf(currentPartner),
          "Receiving party does not prefer new offer over current match"
        );
      }
    }

    // Check if the produced matching (out) is indeed the result of the offers in the trace
    assert(out.length === companies.length, "Output length should match the number of companies");
    assert(isStableMatching(out, companies, candidates), "The matching is not stable");
  }
}

function isStableMatching(
  out: { company: number; candidate: number }[],
  companies: number[][],
  candidates: number[][]
): boolean {
  const N = companies.length;

  for (const { company, candidate } of out) {
    for (let otherCandidate = 0; otherCandidate < N; ++otherCandidate) {
      if (otherCandidate === candidate) continue;

      const companyPrefersOtherCandidate =
        companies[company].indexOf(otherCandidate) < companies[company].indexOf(candidate);

      if (companyPrefersOtherCandidate) {
        const otherCandidatePartnerIdx = out.findIndex(pair => pair.candidate === otherCandidate);
        if (otherCandidatePartnerIdx === -1) continue;

        const otherCandidatePartner = out[otherCandidatePartnerIdx].company;
        const otherCandidatePrefersCompany =
          candidates[otherCandidate].indexOf(company) < candidates[otherCandidate].indexOf(otherCandidatePartner);

        if (otherCandidatePrefersCompany) return false;
      }
    }

    for (let otherCompany = 0; otherCompany < N; ++otherCompany) {
      if (otherCompany === company) continue;

      const candidatePrefersOtherCompany =
        candidates[candidate].indexOf(otherCompany) < candidates[candidate].indexOf(company);

      if (candidatePrefersOtherCompany) {
        const otherCompanyPartnerIdx = out.findIndex(pair => pair.company === otherCompany);
        if (otherCompanyPartnerIdx === -1) continue;

        const otherCompanyPartner = out[otherCompanyPartnerIdx].candidate;
        const otherCompanyPrefersCandidate =
          companies[otherCompany].indexOf(candidate) < companies[otherCompany].indexOf(otherCompanyPartner);

        if (otherCompanyPrefersCandidate) return false;
      }
    }
  }

  return true;
}
